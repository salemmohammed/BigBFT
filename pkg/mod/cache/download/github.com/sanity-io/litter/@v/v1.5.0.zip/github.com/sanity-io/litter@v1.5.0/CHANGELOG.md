# 1.1.0 (2017-11-1)

A slight breaking change. The dump-method of the `Dumper` interface has changed from `Dump` to `LitterDump` to mitigate potential collisions.

# 1.0.0 (2017-10-29)

Tagged 1.0.0.
