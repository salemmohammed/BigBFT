Package `fsync` keeps files and directories in sync. Read the documentation on
[GoDoc](http://godoc.org/github.com/mostafah/fsync).
