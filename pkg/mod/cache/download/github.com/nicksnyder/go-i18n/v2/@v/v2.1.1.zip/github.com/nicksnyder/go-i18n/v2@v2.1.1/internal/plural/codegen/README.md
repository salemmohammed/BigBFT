# How to upgrade CLDR data

1.  Go to http://cldr.unicode.org/index/downloads to find the latest version.
1.  Download the latest version of cldr-common (e.g. http://unicode.org/Public/cldr/37/cldr-common-37.0.zip)
1.  Unzip and copy `common/supplemental/plurals.xml` to this directory.
1.  Run `generate.sh`.
