# Breaking Changes

> See the [Change Log](ChangeLog.md) for a summary of storage library changes.

## Version 0.3.0:
- Removed most panics from the library. Several functions now return an error.
- Removed 2016 and 2017 service versions.