# fnmatch
Updated clone of kballards golang fnmatch gist (https://gist.github.com/kballard/272720)


