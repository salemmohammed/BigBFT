#ifndef USE_LIBSASS_SRC
#include "../../libsass_src/src/c2ast.hpp"
#endif
