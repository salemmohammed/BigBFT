#ifndef USE_LIBSASS_SRC
#include "../../libsass_src/src/prelexer.hpp"
#endif
