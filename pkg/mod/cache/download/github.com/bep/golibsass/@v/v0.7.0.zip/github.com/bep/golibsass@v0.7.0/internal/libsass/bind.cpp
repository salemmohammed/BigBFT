#ifndef USE_LIBSASS_SRC
#include "../../libsass_src/src/bind.cpp"
#endif
