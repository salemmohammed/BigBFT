#ifndef USE_LIBSASS_SRC
#include "../../libsass_src/src/constants.hpp"
#endif
