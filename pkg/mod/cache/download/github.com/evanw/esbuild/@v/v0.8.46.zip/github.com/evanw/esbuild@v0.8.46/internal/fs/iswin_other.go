// +build !js !wasm
// +build !windows

package fs

func CheckIfWindows() bool {
	return false
}
