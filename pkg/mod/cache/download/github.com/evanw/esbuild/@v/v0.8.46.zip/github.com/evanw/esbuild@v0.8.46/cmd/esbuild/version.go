package main

const esbuildVersion = "0.8.46"
